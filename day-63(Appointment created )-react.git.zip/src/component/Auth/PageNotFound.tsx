import { NavLink } from "react-router-dom";

const PageNotFound = () => {
    return (
        <div>
            <NavLink to="/" > Sing In </NavLink>
            PageNotFound
        </div>
    )
};

export default PageNotFound;