import { useEffect, useState } from "react";
import { getMethodFetch } from "../../../APIs/LoginFetch";
import { getLS } from "../../../Utils/Utils";

const Appointment = () => {

    const [appointment,setAppointment] = useState<any>([])

  const getAppointment = async () => {
    const token = getLS("token");
    if (token) {
      const resData = await getMethodFetch(
        "http://localhost:3001/appointment/nonbooked",
        token
      );
      console.log("resData", resData);
      setAppointment(resData)
    }
  };

  useEffect(() => {
    getAppointment();
  }, []);

  return (
    <div>
      <h1>Appointment</h1>
      {
        appointment.length > 0 && appointment.map((ap:any) => {
            return(<p>{ap.id}</p>)
        })
      }
    </div>
  );
};

export default Appointment;
