const BookedAppointment = () => {
    return (
        <div>
            <h1>BookedAppointment</h1>
        </div>
    )
}

export default BookedAppointment;