export const getLS = (key: string) => localStorage.getItem(key);

export const setLS = (key: string, value: any) => localStorage.setItem(key, value)