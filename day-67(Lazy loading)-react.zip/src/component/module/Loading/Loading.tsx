const Loading = () => {
    return (
        <div>
            <span>................loading ................. </span>
        </div>
    )
}
export default Loading;