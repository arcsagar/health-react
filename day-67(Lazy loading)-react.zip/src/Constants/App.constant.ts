export const SIGN_UP_PATH = "/signup";
export const PATIENT_PATH = "/patient";
export const PATIENT_HOME_PATH =  "home";
export const PATIENT_APPOINTMENT_PATH = "appointment";
export const PATIENT_BOOKAPPOINTMENT_PATH = "bookedappointment";
export const ADMIN_PATH = "admin";
